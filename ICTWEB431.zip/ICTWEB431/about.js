
function showPreview1()
{
    let previewContainer = document.getElementById("productPrev1");

    previewContainer.style.display = "flex";
}

function hidePreview1()
{
    let previewContainer = document.getElementById("productPrev1");

    previewContainer.style.display = "none";
}

function showPreview2()
{
    let previewContainer = document.getElementById("productPrev2");

    previewContainer.style.display = "flex";
}

function hidePreview2()
{
    let previewContainer = document.getElementById("productPrev2");

    previewContainer.style.display = "none";
}

function showPreview3()
{
    let previewContainer = document.getElementById("productPrev3");

    previewContainer.style.display = "flex";
}

function hidePreview3()
{
    let previewContainer = document.getElementById("productPrev3");

    previewContainer.style.display = "none";
}